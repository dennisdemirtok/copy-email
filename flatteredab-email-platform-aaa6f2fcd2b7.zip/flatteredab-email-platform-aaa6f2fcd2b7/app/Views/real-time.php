
<div class="widget">
        <!-- Emplacement pour les graphiques ou les données en temps réel -->
        <h3>Real-time activity</h3>
        <p>No activity in progress at the moment.</p>
        <!-- Ajoutez des données en temps réel -->
    </div>